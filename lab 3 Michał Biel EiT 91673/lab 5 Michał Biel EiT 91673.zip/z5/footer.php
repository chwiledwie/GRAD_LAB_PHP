<!— Główny nagłówek strony -->
<header role=”banner”>
<!—Grupa nagłówków, użcie hgroup -->
    <div class="container">
            <div class="intro-text">
                <div class="intro-lead-in">Witaj na stronie zespołu Chwile Dwie!</div>
                <div class="intro-heading">Miło nam Ciebie gościć.</div>
                <a href="#services" class="page-scroll btn btn-xl">Zobacz naszą ofertę</a>
            </div>
        </div>
</header>

<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <span class="copyright">Copyright &copy; Chwile Dwie 2016</span>
                </div>
                <div class="col-md-4">
                    <p>Goście: 
                        <?php include("licznik_wejsc.php"); ?>
                            </p>
                </div>
                <div class="col-md-4">
                    <ul class="list-inline quicklinks">
                        <li><a href="#">Privacy Policy</a>
                        </li>
                        <li><a href="#">Terms of Use</a>
                        </li>
                        
                    </ul>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>

