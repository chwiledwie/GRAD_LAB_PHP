<?php
require 'header.php';
?>

    
    
    <div class="container">
            
            <div class="demo-wrapper css3-bounce-effect">
		<div class="css3-notification">
		<h1 class="animated tada">Dziękuję za zarejestrowanie się. Teraz możesz się zalogować: <?php echo '<br /><a href="login.php">Logowanie</a></p>';?></h1>	
                  
		</div>
	</div>
           
        </div>

	<?php
require 'footer2.php';
?>